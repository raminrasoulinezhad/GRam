/*
 * Service worker for the installed (home-screen) app.
 *
 * Goal: FitRam opens and works in a gym basement with no signal. The app shell - HTML, the JS
 * bundle, icons - is cached on install and served from cache first. Exercise photographs come
 * from an external CDN and are cached opportunistically as you view them.
 *
 * Deliberately simple. There is no user data here to sync: everything the user records lives in
 * localStorage, which the browser persists independently of this cache.
 */

// Bumped by scripts/build-web.mjs on every build so a new deploy replaces the old cache.
const CACHE = 'fitram-0.1.0-msayygxm';

/*
 * Precache list, injected at build time by scripts/build-web.mjs.
 *
 * The JS bundle's filename is content-hashed, so it cannot be written here by hand - and it
 * cannot be left to the fetch handler either. The service worker only registers on `load`, by
 * which point the browser has already fetched the bundle without it, so nothing would be cached
 * until the *second* visit. Anyone who installed the app and immediately went to a gym with no
 * signal would get a blank screen. Precaching on install fixes that.
 */
const BUILD_ASSETS = ["/_expo/static/js/web/entry-3154526fff2b41e837e64f9aa61de369.js","/assets/node_modules/@expo/vector-icons/build/vendor/react-native-vector-icons/Fonts/Ionicons.b4eb097d35f44ed943676fd56f6bdc51.ttf","/assets/node_modules/expo-router/assets/arrow_down.017bc6ba3fc25503e5eb5e53826d48a8.png","/assets/node_modules/expo-router/assets/error.d1ea1496f9057eb392d5bbf3732a61b7.png","/assets/node_modules/expo-router/assets/file.19eeb73b9593a38f8e9f418337fc7d10.png","/assets/node_modules/expo-router/assets/forward.d8b800c443b8972542883e0b9de2bdc6.png","/assets/node_modules/expo-router/assets/pkg.ab19f4cbc543357183a20571f68380a3.png","/assets/node_modules/expo-router/assets/react-navigation/elements/back-icon-mask.0a328cd9c1afd0afe8e3b1ec5165b1b4.png","/assets/node_modules/expo-router/assets/react-navigation/elements/back-icon.35ba0eaec5a4f5ed12ca16fabeae451d.png","/assets/node_modules/expo-router/assets/react-navigation/elements/clear-icon.c94f6478e7ae0cdd9f15de1fcb9e5e55.png","/assets/node_modules/expo-router/assets/react-navigation/elements/clear-icon.c94f6478e7ae0cdd9f15de1fcb9e5e55@2x.png","/assets/node_modules/expo-router/assets/react-navigation/elements/clear-icon.c94f6478e7ae0cdd9f15de1fcb9e5e55@3x.png","/assets/node_modules/expo-router/assets/react-navigation/elements/clear-icon.c94f6478e7ae0cdd9f15de1fcb9e5e55@4x.png","/assets/node_modules/expo-router/assets/react-navigation/elements/close-icon.808e1b1b9b53114ec2838071a7e6daa7.png","/assets/node_modules/expo-router/assets/react-navigation/elements/close-icon.808e1b1b9b53114ec2838071a7e6daa7@2x.png","/assets/node_modules/expo-router/assets/react-navigation/elements/close-icon.808e1b1b9b53114ec2838071a7e6daa7@3x.png","/assets/node_modules/expo-router/assets/react-navigation/elements/close-icon.808e1b1b9b53114ec2838071a7e6daa7@4x.png","/assets/node_modules/expo-router/assets/react-navigation/elements/search-icon.286d67d3f74808a60a78d3ebf1a5fb57.png","/assets/node_modules/expo-router/assets/sitemap.412dd9275b6b48ad28f5e3d81bb1f626.png","/assets/node_modules/expo-router/assets/unmatched.20e71bdf79e3a97bf55fd9e164041578.png"];

const SHELL = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  ...BUILD_ASSETS,
];

const PHOTO_HOST = 'raw.githubusercontent.com';

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      // A single missing entry must not fail the whole install, so each is added individually.
      .then((cache) => Promise.allSettled(SHELL.map((url) => cache.add(url))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Exercise photographs: cache on first view, then serve offline forever.
  if (url.hostname === PHOTO_HOST) {
    event.respondWith(
      caches.match(request).then(
        (hit) =>
          hit ??
          fetch(request)
            .then((response) => {
              if (response.ok) {
                const copy = response.clone();
                caches.open(CACHE).then((cache) => cache.put(request, copy));
              }
              return response;
            })
            .catch(() => new Response('', { status: 504 })),
      ),
    );
    return;
  }

  if (url.origin !== self.location.origin) return;

  /*
   * Navigations always resolve to the app shell. expo-router is a single-page app, so every
   * route renders from the same document and the path is interpreted client-side.
   *
   * Falling back on a failed *fetch* is not enough: a static host without SPA rewrite rules
   * answers /body with a perfectly successful 404 page, not a network error. So any non-OK
   * response falls back too, which makes an installed app work regardless of how the host is
   * configured. (public/_redirects handles it server-side on Netlify and Cloudflare Pages.)
   */
  if (request.mode === 'navigate') {
    const shell = () => caches.match('/index.html').then((hit) => hit ?? caches.match('/'));
    event.respondWith(
      fetch(request)
        .then((response) => (response.ok ? response : shell().then((hit) => hit ?? response)))
        .catch(() => shell()),
    );
    return;
  }

  // Everything else (the JS bundle, fonts, icons): cache first, since filenames are hashed.
  event.respondWith(
    caches.match(request).then(
      (hit) =>
        hit ??
        fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        }),
    ),
  );
});
